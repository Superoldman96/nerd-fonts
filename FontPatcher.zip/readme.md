
# Nerd Fonts

This is the font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Licensing

This script has an MIT license.

The added icons' authors and licenses can be found in the `src/` subdirectory.

## Version
This archive is created from

        commit e399466eaaebae6cb51b8c53ae4a2dcd2f404346
        Author: Fini <ulf.fini.jastrow@desy.de>
        Date:   Mon Jan 26 15:08:41 2026 +0100
        
            Merge pull request #1979 from ryanoasis/feature/zsh
            
            Add zsh icon
