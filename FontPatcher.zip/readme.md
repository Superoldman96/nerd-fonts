
# Nerd Fonts

This is the font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Licensing

This script has an MIT license.

The added icons' authors and licenses can be found in the `src/` subdirectory.

## Version
This archive is created from

        commit 20612ba75c67ca72b9e9a6528f5e427a55015fe8
        Author: Fini <ulf.fini.jastrow@desy.de>
        Date:   Sat Feb 7 12:29:54 2026 +0100
        
            Merge pull request #1980 from GoldPigg/braille-support
            
            Add Braille support (with generator)
