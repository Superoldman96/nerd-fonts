
# Nerd Fonts

This is the font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Licensing

This script has an MIT license.

The added icons' authors and licenses can be found in the `src/` subdirectory.

## Version
This archive is created from

        commit d7c5c11e9c044630df3b7de622b1989fb826d794
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Sat Feb 7 14:11:48 2026 +0100
        
            doc: Update font-patcher params
            
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
