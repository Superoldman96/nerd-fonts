# Devicons

From the Devicons the non-linemark versions are selected and assembled into a custom
icon font. This font guarantees that the codepoints of existing icons do not change
when other icons are added or removed.

For more information have a look at the upstream website: https://github.com/devicons/devicon

The helper scripts need to be called in this order (note the individual prerequisites):
* `analyze`
* `generate` (possibly via `fontforge`)

Version: 2.16.0.custom
